# GroupProject7: Building and testing API clients
-Building a command line interface that interacts with your API 

-Writing an automated testing suite so you can modify your API while still guaranteeing that other clients won’t break

(From the commands instructed in Group Project 5)
In this project, we will allow the user to:
1. Return the MD5 hash of a user input string
2. Return the factorial of a user input integer
3. Return an array of Fibonacci numbers that are less than and equal to the user input integer
4. Return a boolean value on whether the user input integer is prime or not
5. Return a boolean value on whether a value of an input was posted successfully on the class Slack or not
